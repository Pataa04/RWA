<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>PHP DZ 1</title>
</head>
<body>

<?php

// Zadatak 1 - Ispis brojeva od 1 do 20 i njihovih kvadrata
echo "<h3>Zadatak 1 - rješenje:</h3>";

for ($i = 1; $i <= 20; $i++) {              //koristimo for petlju koja prolazi od 1. do 20. pozicije
    echo $i . " - " . ($i * $i) . "<br>";   //echo za ispis komanda[svaku poziciju mnozimo samu sa sobom i pisemo "-"radi ljepseg izgleda]
}


// Zadatak 2 - Suma prvih 100 prirodnih brojeva pomoću for petlje
echo "<h3>Zadatak 2 - rješenje:</h3>";

$suma = 0;       //sumu inicijaliziramo na 0

for ($i = 1; $i <= 100; $i++) {  //for petlja prolazi od 1. do 100. pozicije
    $suma += $i;                 //svaku iteraciju zbrajamo
}

echo "Suma prvih 100 prirodnih brojeva iznosi: " . $suma . "<br>";  //ispis rez


// Zadatak 3 - Suma prvih 100 prirodnih brojeva pomoću while petlje
echo "<h3>Zadatak 3 - rješenje:</h3>";

$suma = 0;              //sumu inicijaliziramo na 0, i na 1 jer s 1 pocinjemo
$i = 1;            
 
while ($i <= 100) {       //petlja radi sve dok ne dodjemo do 100
    $suma += $i;          //zbrajaj svaku iteraciju i inkrementiraj
    $i++;
}

echo "Suma prvih 100 prirodnih brojeva iznosi: " . $suma . "<br>";  //ispis rez


// Zadatak 4 - Ispis svih parnih brojeva od 1 do 100
echo "<h3>Zadatak 4 - rješenje:</h3>";

for ($i = 1; $i <= 100; $i++) {        //petalja za prolazak kroz 100 brojeva
    if ($i % 2 == 0) {                 //uvjet petlje ako trenutni i djeljen sa 2 daje ostatak 0, ispisi ga paran je
        echo $i . "<br>";
    }
}


// Zadatak 5 - Ispis svih troznamenkastih parnih brojeva
echo "<h3>Zadatak 5 - rješenje:</h3>";

for ($i = 100; $i <= 999; $i++) {      //slicna stvar kao u proslm zadatku, petlja prolazi od 100 do 999
    if ($i % 2 == 0) {                 //trazimo uvijetom parne troznamenkaste i ispisujemo ih
        echo $i . "<br>";
    }
}


// Zadatak 6 - Ispis svih dvoznamenkastih brojeva djeljivih s 3 ili 5 ili s oba
echo "<h3>Zadatak 6 - rješenje:</h3>";

for ($i = 10; $i <= 99; $i++) {        //petlja koja prolazi kroz sve dvoznamenkaste brojeve
    if ($i % 3 == 0 || $i % 5 == 0) {  //provjera djeljivosti sa 3 i 5, ako su djeljivi ispisi
        echo $i . "<br>";
    }
}


// Zadatak 7 - Rad s poljem godina i broja stanovnika
echo "<h3>Zadatak 7 - rješenje:</h3>"; // ispis naslova zadatka

$grad = array(                 // definiranje polja (godina => broj stanovnika)
    1995 => 24000,
    1997 => 25510,
    1998 => 29154,
    2000 => 32124,
    2002 => 33114
);

$ukupno = 0;                  // varijabla za zbroj svih stanovnika
$broj_godina = count($grad); // broj elemenata u polju (koliko godina ima)
$max_stanovnika = 0;         // početna vrijednost maksimuma
$godina_max = 0;             // godina u kojoj je maksimum

foreach ($grad as $godina => $stanovnici) { // prolazak kroz polje (ključ => vrijednost)

    $ukupno += $stanovnici;  // dodavanje trenutnog broja stanovnika u ukupni zbroj

    if ($stanovnici > $max_stanovnika) { // provjera je li trenutni broj veći od maksimuma

        $max_stanovnika = $stanovnici;   // spremamo novi najveći broj stanovnika
        $godina_max = $godina;           // spremamo godinu u kojoj se to dogodilo
    }
}

$prosjek = $ukupno / $broj_godina; // računanje prosjeka (suma / broj godina)

echo "Prosječan broj stanovnika je: " . $prosjek . "<br>"; // ispis prosjeka
echo "Najviše stanovnika bilo je godine: " . $godina_max . "<br>"; // ispis godine maksimuma
echo "Mjerenje se provodilo kroz " . $broj_godina . " godina.<br>"; // ispis broja godina


// Zadatak 8 - Funkcija za provjeru prostog broja i ispis prostih brojeva manjih od 100
echo "<h3>Zadatak 8 - rješenje:</h3>";

function jeProst($broj) {            //ovdje definiramo funckiju koja ce nam provjeravati je li broj prost ili nije
    if ($broj < 2) {
        return false;					//uvijet ako je broj 1 nije prost niti slozen
    }

    for ($i = 2; $i <= $broj; $i++) {  //prolazimo od 2 do unesenog broja
        if ($broj % $i == 0) {         //ako broj ima djelitelja osim sebe samoga slozen je i vraca se 0
            return false;
        }
    }

    return true;   //inace vrati 1
}

for ($i = 1; $i < 100; $i++) {   //pravimo petlju koja nam prodje kroz 100 brojeva
    if (jeProst($i)) {           //ako nam je funckija vratila true, za neko i, ispisi to i
        echo $i . "<br>";
    }
}


// Zadatak 9 - Zbrajanje članova polja pomoću foreach petlje
echo "<h3>Zadatak 9 - rješenje:</h3>"; // ispis naslova zadatka u browseru

$brojevi = array(1, 22, 3, 4, 5, 55, 12, 49, 94, 23, 7);  // definiramo polje (niz) brojeva

$suma = 0;  // inicijaliziramo varijablu suma na 0 (početna vrijednost)

// foreach prolazi kroz svaki element polja $brojevi
// svaki element redom sprema u varijablu $broj
foreach ($brojevi as $broj) {  
    $suma += $broj; // dodajemo trenutni broj na ukupnu sumu
}

echo "Suma članova polja iznosi: " . $suma . "<br>"; // ispis konačne sume

// Zadatak 10 - Izračun površine pravokutnika
echo "<h3>Zadatak 10 - rješenje:</h3>";

$a = 5;                       //jednostavan zadatak, definiramo varijable s nekim vrijednostima, moraju biti razliciti a i b zato sto je pravokutnik
$b = 10;

$pov_pravokutnik = $a * $b;      //definiramo varijablu povrsina i da je ona jednaka a * b

echo "Površina pravokutnika širine " . $a . " i dužine " . $b . " iznosi " . $pov_pravokutnik . ".";  //ispis rezultata

?>

</body>
</html>